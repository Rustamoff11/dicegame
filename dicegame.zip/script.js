const rooldice = document.querySelector(".btn--roll");
const diceel = document.querySelector(".dice");
const current0 = document.querySelector("#current--0");
const current1 = document.querySelector("#current--1");
const holldice = document.querySelector(".btn--hold");
let currentscore = 0;
let activeplayer = 0;
let totalscore = [0, 0];
let gameover = true;
diceel.style.display = "none";

rooldice.addEventListener("click", () => {
  if (gameover) {
    diceel.style.display = "block";
    const randomnumber = Math.trunc(Math.random() * 6) + 1;
    diceel.src = `dice-${randomnumber}.png`;
    currentscore += randomnumber;
    if (randomnumber > 1) {
      document.getElementById(`current--${activeplayer}`).textContent =
        currentscore;
    } else {
      document.getElementById(`current--${activeplayer}`).textContent = 0;
      activeplayer = activeplayer == 0 ? 1 : 0;
      currentscore = 0;
      document.querySelector(".player--0").classList.toggle("player--active");
      document.querySelector(".player--1").classList.toggle("player--active");
    }
  }
});

holldice.addEventListener("click", () => {
  if (gameover) {
    totalscore[activeplayer] += currentscore;
    document.getElementById(`score--${activeplayer}`).textContent =
      totalscore[activeplayer];

    if (totalscore[activeplayer] >= 20) {
      document
        .querySelector(`.player--${activeplayer}`)
        .classList.add("player--winner");
      gameover = false;
    } else {
      document.getElementById(`current--${activeplayer}`).textContent = 0;
      activeplayer = activeplayer == 0 ? 1 : 0;
      currentscore = 0;
      document.querySelector(".player--0").classList.toggle("player--active");
      document.querySelector(".player--1").classList.toggle("player--active");
    }
  }
});

function resetGame() {
  currentscore = 0;
  activeplayer = 0;
  totalscore = [0, 0];
  gameover = true;
  diceel.style.display = "none";
  current0.textContent = 0;
  current1.textContent = 0;
  document.getElementById("score--0").textContent = 0;
  document.getElementById("score--1").textContent = 0;
  document.querySelector(".player--0").classList.remove("player--winner");
  document.querySelector(".player--1").classList.remove("player--winner");
  document.querySelector(".player--0").classList.add("player--active");
  document.querySelector(".player--1").classList.remove("player--active");
}

document.addEventListener("DOMContentLoaded", () => {
  resetGame();
});

document.querySelector(".btn--new").addEventListener("click", () => {
  resetGame();
});
